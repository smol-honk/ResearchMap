$(function() {
    $('#dateStart').pickadate();
    $('#dateEnd').pickadate();
    $("#dateStart").attr("readonly", false);
    $("#dateEnd").attr("readonly", false);
    $('#dateStart').tooltip();
    $('#dateEnd').tooltip();
  });

$(function() {
    $('#fieldStart').pickadate();
    $('#fieldEnd').pickadate();
    $("#fieldStart").attr("readonly", false);
    $("#fieldEnd").attr("readonly", false);
    $('#fieldStart').tooltip();
    $('#fieldEnd').tooltip();
  });
